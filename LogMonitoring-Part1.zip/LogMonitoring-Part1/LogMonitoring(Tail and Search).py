"""
Log Monitoring (Tail & Search):
The following script continuously reads the end(tail) of a log file and
searches for specific words like "ERROR", "WARN" , etc
"""
import time

log_file = "log.txt"
monitor_words = ["ERROR","FAILURE"]

with open(log_file,"r") as file:
    print(" --- welcome to log monitoring application ----")

    # Seek to end of the file
    file.seek(0,2)

    # Loop indefinitely
    while True:
        # read a line from file
        line = file.readline() 

        # If there is no new content, sleep for sometime.
        if not line:
            time.sleep(1)
            continue

        # if a line is read, search for the monitoring words
        for word in monitor_words: 
            if word in line:
                print(line)