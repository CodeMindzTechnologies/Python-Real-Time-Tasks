"""
Cut and Paste file contents - copy the contents of file_1 to file_2 and delete file_1 
"""
import os

read_file = "read_file.txt"
write_file = "write_file.txt"

try:
    # Open and read the source file content to a variable in memory
    file = open(read_file,"r")
    content = file.read()
    file.close()

    # Open destination file and write content to it
    file = open(write_file,"a")
    file.write(content)
    file.close()

    # Delete the source file
    os.remove(read_file)

except Exception as e:
    print("ERROR: ",e)


print(" ----- END of PROGRAM ----- ")
