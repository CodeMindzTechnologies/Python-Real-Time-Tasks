"""
Requirement:
------------
Search "FAILURE or ERROR word" and  "OrderApplication" word in the same line
Eg:
ERROR: Low disk space --------> This line should not be found
FAILURE: Service failed OrderApplication --------> This line should be found 

Regular Expression:
--------------------
- Used for searching, manipulating text. 
- import "re" module

Functions:
re.search(pattern, string) - Searches the string for the first occurrence of the pattern.
.: Matches any character except a newline (\n)
    eg: re.search("c.t", "cat")  # Matches 'cat'
*: Matches zero or more repetitions of the preceding character.
    Eg: re.search("a*", "a aa aaa")  # Matches 'aaa'

"""


import time
import re 

log_file = "log.txt"
monitor_pattern = r"(FAILURE|ERROR).*OrderApplication"

with open(log_file,"r") as file:
    print(" --- welcome to log monitoring application ----")

    # Seek to end of the file
    file.seek(0,2)

    # Loop indefinitely
    while True:
        # read a line from file
        line = file.readline() 

        # If there is no new content, sleep for sometime.
        if not line:
            time.sleep(1)
            continue

        # if a line is read, search for the monitoring words
        if re.search(monitor_pattern,line):
            print(line)