from PIL import Image, ImageDraw, ImageFont
import random
import string

# create image
width = 200
height = 100
image = Image.new('RGB',(width,height),'white')
draw = ImageDraw.Draw(image)

# create a string with 6 characters chosen randomly
list_of_characters = string.ascii_letters + string.digits
captcha_text = ''.join(random.choices(list_of_characters,k=6))

# draw the string on the image
font = ImageFont.load_default()
text_x = (width - draw.textlength(captcha_text,font=font)) // 2
text_y = (height - font.size) // 2
draw.text((text_x,text_y), captcha_text, font=font, fill='grey')

# fill noise in the image
for i in range(500):
    x = random.randint(0,width)
    y = random.randint(0,height)
    draw.point((x,y),fill='black')

# show the image
image.show()
