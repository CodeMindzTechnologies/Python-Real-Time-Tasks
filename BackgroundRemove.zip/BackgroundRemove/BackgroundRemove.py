"""
Requirement: Remove background from an image
Example: https://www.remove.bg/
"""
from rembg import remove 
input_image = "input2.jpg"
output_image = "output2.png"

try:
    with open(input_image,"rb") as input_file:
        in_image = input_file.read()

    out_image = remove(in_image)

    with open(output_image,"wb") as output_file:
        output_file.write(out_image)

    print(" Background from the input Image is removed successfully ")

except Exception as e:
    print("Error: ",e)